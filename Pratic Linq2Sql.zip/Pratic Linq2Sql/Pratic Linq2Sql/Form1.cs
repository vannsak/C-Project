﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratic_Linq2Sql
{
    public partial class Form1 : Form
    {
        dbEmployeeContextDataContext db = new dbEmployeeContextDataContext();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnLoadPic.Click += (obj, ex) => loadPic();
            btnClearPic.Click += (obj, ex) => clearPic();

            loadData();
            btnAdd.Click += (obj, ex) => { addEmployee(); loadData(); };
            btnAddFamily.Click += (obj, ex) => { addFamily(); };
        }
        void loadPic()
        {
            var diag = new OpenFileDialog();
            diag.Filter = "Image| * .jpg";
            if (diag.ShowDialog() == DialogResult.OK)
                picImage.Image = Image.FromFile(diag.FileName);
        }
        void clearPic()
        {
            picImage.Image = null;
        }
        void addFamily()
        {
            var obj = new clsEmployeeType();
            obj.Name = txtFamilyName.Text;
            obj.FType = cboFamilyType.SelectedItem.ToString();
            lstFamily.Items.Add(obj);
        }
        void addEmployee()
        {
            var objNewEmployee = new tblEmployee();
            objNewEmployee.FName = txtFirstName.Text;
            objNewEmployee.LName = txtLastName.Text;
            objNewEmployee.Gender = cboGender.SelectedItem.ToString();
            objNewEmployee.DOB = dbDOB.Value;
            objNewEmployee.Salary = numSalary.Value;

            if (picImage.Image != null) 
            {
                var mr = new System.IO.MemoryStream();
                picImage.Image.Save(mr, System.Drawing.Imaging.ImageFormat.Jpeg);
                mr.Position = 0;
                objNewEmployee.photo = mr.ToArray();
            }
            else
                objNewEmployee.photo = null;

            db.GetTable<tblEmployee>().InsertOnSubmit(objNewEmployee);
            db.SubmitChanges();
            
            foreach(var itm in lstFamily.Items)
            {
                var obj = itm as clsEmployeeType;
                var objNewFamily = new tblFamily();
                objNewFamily.Name = obj.Name;
                objNewFamily.type = obj.FType;
                objNewFamily.FID = objNewEmployee.ID;
                db.GetTable<tblFamily>().InsertOnSubmit(objNewFamily);
                db.SubmitChanges();

            } 
        }
        void loadData()
        {
            var res = db.GetTable<tblEmployee>().Select(n => n);

            bindingSource1.DataSource = res;
           
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var res = db.GetTable<tblEmployee>().Where(n => n.ID == int.Parse(txtSearchID.Text) ).Select(n => n);

            bindingSource1.DataSource = res;

        }

        private void dgData_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var obj = dgData.SelectedRows[0].DataBoundItem as tblEmployee;
            db.GetTable<tblEmployee>().DeleteOnSubmit(obj);
            var fobj = db.GetTable<tblFamily>().Where(n => n.FID == obj.ID);
            db.SubmitChanges();
            loadData();
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var obj = dgData.SelectedRows[0].DataBoundItem as tblEmployee;
            var objUpdate = db.GetTable<tblFamily>().Where(n => n.FID == obj.ID);
            db.SubmitChanges();
            loadData();
        }
    }

    public class clsEmployeeType
    {
        public string Name { get; set; }
        public string FType { get; set; }
        public override string ToString()
        {
            return Name + "-" + FType;
        }

    }
}
